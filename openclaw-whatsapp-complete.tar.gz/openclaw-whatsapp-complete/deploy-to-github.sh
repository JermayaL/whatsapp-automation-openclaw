#!/bin/bash
# Deploy OpenClaw WhatsApp Automation to GitHub

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   Deploy OpenClaw WhatsApp Automation to GitHub           ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Configuration
REPO_DIR="$HOME/whatsapp-automation-openclaw/whatsapp-automation-openclaw/whatsapp-automation-openclaw"
TOKEN="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"
REPO_URL="https://${TOKEN}@github.com/JermayaL/whatsapp-automation-openclaw.git"

echo "📁 Navigating to repository..."
cd "$REPO_DIR" || exit 1

echo ""
echo "🗑️  Cleaning old files..."
# Keep only .git directory
find . -maxdepth 1 ! -name '.git' ! -name '.' ! -name '..' -exec rm -rf {} +

echo ""
echo "📥 Copying new OpenClaw files..."

# Create directory structure
mkdir -p workspace/skills/spreadsheet-trigger
mkdir -p workspace-filter/.prose
mkdir -p config
mkdir -p docs
mkdir -p .github/workflows

# Copy files from the complete package
# Note: Adjust source path based on where files are extracted
SOURCE_DIR="/path/to/extracted/openclaw-whatsapp-complete"

if [ ! -d "$SOURCE_DIR" ]; then
    echo "❌ Source directory not found: $SOURCE_DIR"
    echo "Please extract openclaw-whatsapp-complete.tar.gz first"
    exit 1
fi

# Copy workspace files
cp -r "$SOURCE_DIR/workspace/"* workspace/
cp -r "$SOURCE_DIR/workspace-filter/"* workspace-filter/

# Copy config
cp "$SOURCE_DIR/config/openclaw.json" config/

# Copy docs
cp "$SOURCE_DIR/docs/"* docs/

# Copy root files
cp "$SOURCE_DIR/README.md" .
cp "$SOURCE_DIR/LICENSE" . 2>/dev/null || echo "MIT License

Copyright (c) 2026 JermayaL

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the \"Software\"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE." > LICENSE

# Create .gitignore
cat > .gitignore << 'EOF'
# OpenClaw data
google-credentials.json
processed-leads.json
*.log
logs/

# Environment
.env
*.env

# Node
node_modules/
package-lock.json

# OS
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp

# Workspace (user-specific)
workspace-human/
*.bak
EOF

echo ""
echo "📝 Creating package.json..."
cat > package.json << 'EOF'
{
  "name": "openclaw-whatsapp-automation",
  "version": "2.0.0",
  "description": "Complete WhatsApp lead automation using OpenClaw",
  "keywords": [
    "whatsapp",
    "automation",
    "openclaw",
    "ai-agent",
    "lead-generation",
    "google-sheets",
    "claude"
  ],
  "author": "JermayaL",
  "license": "MIT",
  "dependencies": {
    "google-spreadsheet": "^4.1.2"
  },
  "engines": {
    "node": ">=22.0.0"
  }
}
EOF

echo ""
echo "📋 Checking files..."
find . -type f ! -path './.git/*' | head -20

echo ""
echo "➕ Adding files to git..."
git add -A

echo ""
echo "📊 Git status:"
git status --short

echo ""
echo "💾 Committing..."
git commit -m "feat: Complete OpenClaw WhatsApp automation system

- Added OpenClaw-based architecture
- Spreadsheet trigger skill (Google Sheets integration)
- Filter agent for lead qualification
- Prose workflow for complex logic
- Multi-agent system (filter → human handover)
- Complete documentation
- Production ready

Components:
- workspace/skills/spreadsheet-trigger/ - Monitors Google Sheets
- workspace-filter/ - AI filter agent
- config/openclaw.json - Complete configuration
- docs/ - Setup guides and architecture

Features:
- Automatic lead detection (30 seconds)
- WhatsApp automation via OpenClaw
- AI-powered qualification (Claude 4.5)
- Session isolation per lead
- Rate limiting (WhatsApp compliant)
- 24/7 daemon operation
" || echo "Nothing to commit"

echo ""
echo "🚀 Pushing to GitHub..."
git push "$REPO_URL" main --force

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                    ✅ SUCCESS!                             ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "Repository updated: https://github.com/JermayaL/whatsapp-automation-openclaw"
echo ""
echo "Next steps:"
echo "1. ⚠️  Delete your GitHub token: https://github.com/settings/tokens"
echo "2. 📚 Review README.md in the repo"
echo "3. 🚀 Follow docs/SETUP_GUIDE.md to deploy"
echo ""
